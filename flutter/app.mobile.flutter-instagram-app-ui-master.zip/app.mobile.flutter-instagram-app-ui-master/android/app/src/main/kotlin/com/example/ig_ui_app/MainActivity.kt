package com.example.ig_ui_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
