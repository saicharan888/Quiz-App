import 'package:flutter/material.dart';

Color getThemeColor() {
  return const Color(0xfff4267B2);
}