enum Status {
  NotRequested,
  RequestSuccessful,
  RequestInProcess,
  RequestFailed
}